import React from "react";
import "./App.css";
import Grid from "./components/Grid/Grid";
import CardPage from "./pages/CardPage";
import { ThemeProvider, useTheme } from "./context/ThemeContext";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Link } from "react-router-dom";

function App() {
  return (
    <ThemeProvider>
      <Router>
        <ThemedApp />
      </Router>
    </ThemeProvider>
  );
}

function ThemedApp() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div
      className="app"
      style={{ backgroundColor: theme.background, color: theme.text }}
    >
      {/* Sticky Header */}
      <header
        className="sticky-header"
        style={{
          backgroundColor: theme.headerBackground,
          color: theme.headerText,
        }}
      >
        <h1>
          <Link to="/" style={{ textDecoration: "none", color: theme.headerText }}>
            kyledominick
          </Link>
        </h1>
      </header>

      {/* Main Content */}
      <main
        className="main-content"
        style={{
          backgroundColor: theme.background,
          color: theme.text,
        }}
      >
        <Routes>
          <Route path="/" element={<Grid />} />
          <Route path="/card/:id" element={<CardPage />} />
        </Routes>
      </main>

      {/* Sticky Footer */}
      <footer
        className="sticky-footer"
        style={{
          backgroundColor: theme.footerBackground,
          color: theme.footerText,
        }}
      >
        <span
          className="material-symbols-outlined theme-toggle-icon"
          onClick={toggleTheme}
          style={{
            cursor: "pointer",
            fontSize: "24px",
            color: theme.footerText,
          }}
        >
          {theme.name === "light" ? "dark_mode" : "light_mode"}
        </span>
      </footer>
    </div>
  );
}

export default App;