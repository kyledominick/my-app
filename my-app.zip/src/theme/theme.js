const lightTheme = {
  background: "rgb(245, 245, 245)",
  text: "#333",
  cardColors: ["#FF5733", "#33FF57", "#3357FF", "#FF33A1", "#FFC300", "#DAF7A6", "#581845", "#900C3F", "#C70039"],
  iconColor: "#000",
  name: "light",
  background: "#ffffff", // Main content background
  text: "#000000", // Main content text
  headerBackground: "#f1f1f1", // Header background
  headerText: "#000000", // Header text
  footerBackground: "#f1f1f1", // Footer background
  footerText: "#000000", // Footer text
};

const darkTheme = {
  background: "rgb(75, 75, 75)",
  text: "#f5f5f5",
  cardColors: ["#FF5733", "#33FF57", "#3357FF", "#FF33A1", "#FFC300", "#DAF7A6", "#581845", "#900C3F", "#C70039"],
  iconColor: "#fff",
  name: "dark",
  background: "#121212", // Main content background
  text: "#ffffff", // Main content text
  headerBackground: "#1e1e1e", // Header background
  headerText: "#ffffff", // Header text
  footerBackground: "#1e1e1e", // Footer background
  footerText: "#ffffff", // Footer text
};

export { lightTheme, darkTheme };